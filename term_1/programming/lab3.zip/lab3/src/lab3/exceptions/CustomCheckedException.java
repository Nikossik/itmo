package lab3.exceptions;

public class CustomCheckedException extends Exception {
    public CustomCheckedException(String message) {
        super(message);
    }
}
