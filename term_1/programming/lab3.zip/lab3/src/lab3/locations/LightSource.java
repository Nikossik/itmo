package lab3.locations;

public interface LightSource {
    void turnOn();
    void turnOff();
}

