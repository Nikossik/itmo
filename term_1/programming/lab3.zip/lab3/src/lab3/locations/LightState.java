package lab3.locations;

public enum LightState {
    ON,
    OFF
}

